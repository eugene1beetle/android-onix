package com.example.onix_android.Interfaces;

import android.view.View;

public interface ItemClickListener {

    void onClickListener(View v, int posstion);

}
